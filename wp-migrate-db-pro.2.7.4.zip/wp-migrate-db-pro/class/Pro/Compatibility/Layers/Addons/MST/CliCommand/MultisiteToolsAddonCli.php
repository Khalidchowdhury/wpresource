<?php

namespace DeliciousBrains\WPMDBMST\CliCommand;

class MultisiteToolsAddonCli {
    //Silence is golden.
}
