<?php

namespace DeliciousBrains\WPMDB\Pro\Cli\Extra;

//@TODO remove class once moved to 2.0 or a enough people are off 1.9.* branch
class Initialize
{
	public function __construct()
	{
	}
	public function registerAddon()
	{
	}
}
