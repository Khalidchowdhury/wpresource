<?php 

require_once(get_template_directory().'/inc/enqueue.php');
require_once(get_template_directory().'/inc/theme-setup.php');
require_once(get_template_directory().'/inc/tgm.php');
require_once(get_template_directory().'/inc/wp-bootstrap-navwalker.php');
require_once(get_template_directory().'/inc/acf.php');
require_once(get_template_directory().'/inc/block-support.php');
// require_once(get_template_directory().'/inc/custom-widgets.php');
// require_once(get_template_directory().'/inc/woocommerce_support.php');

?>
