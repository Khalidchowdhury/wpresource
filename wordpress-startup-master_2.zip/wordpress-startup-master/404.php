<?php get_header();?>

<div class="text-center error_page">
    <h1><?php __('404 Page not found', 'mukto'); ?></h1>
</div>
<?php get_footer();?>