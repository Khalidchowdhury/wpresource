<footer id="footer">
    <!-- <div class="footer_menu">
        <?php wp_nav_menu(array(
            'theme_location' => 'footer_menu',
            'container' => 'nav',
            'container_class' => '',
            'menu_class' => 'footer-menu',
            'menu_id' => 'footermenu',
            'depth' => '0',
            'fallback_cb' => 'WP_Bootstrap_Navwalker::fallback',
            'walker' => new WP_Bootstrap_Navwalker()
        )); 
         ?>
    </div> -->

</footer>


<?php wp_footer(); ?>
</body>

</html>