<?php defined( 'ABSPATH' ) || exit; ?>
<div class="below-title beta-feedback warning inline-message">
	<strong>Thanks again for testing the 2.0 beta!</strong>

	<p>How has your experience been so far with the 2.0 beta? Please send an email to <a href="mailto:wpmdb@deliciousbrains.com">wpmdb@deliciousbrains.com</a> to let us know what works well and what doesn’t. We’re eager to hear any feedback - good or bad - that you’d be willing to share :)</p>
</div>
